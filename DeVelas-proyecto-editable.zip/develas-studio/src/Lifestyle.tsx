import {Video} from '@remotion/media';
import {AbsoluteFill,Interactive,interpolate,staticFile,useCurrentFrame} from 'remotion';
import {Atmosphere,typography} from './design';
export const Lifestyle=()=>{
 const frame=useCurrentFrame();
 return <AbsoluteFill style={{backgroundColor:'#362315'}}>
  <Video name="Living — atardecer" src={staticFile('lifestyle.mp4')} muted durationInFrames={174} objectFit="cover" style={{width:'100%',height:'100%'}}/>
  <Atmosphere/>
  <Interactive.Div name="Promesa DeVelas" style={{...typography,position:'absolute',top:315,left:100,right:160,fontSize:86,lineHeight:1.03,fontWeight:500,opacity:interpolate(frame,[5,17],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>Transformá tu espacio<br/>con <span style={{fontWeight:700}}>DeVelas</span> 🕯️</Interactive.Div>
  <Interactive.Div name="Botón de compra" style={{fontFamily:'Cormorant, serif',position:'absolute',top:1350,left:100,right:160,height:104,borderRadius:52,backgroundColor:'#FFF3E0',boxShadow:'0 8px 30px rgba(0,0,0,.24)',color:'#412718',fontSize:48,fontWeight:600,display:'flex',alignItems:'center',justifyContent:'center',opacity:interpolate(frame,[18,30],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'}),translate:interpolate(frame,[18,36],['0px 20px','0px 0px'],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>Comprar en develasmontevideo.com</Interactive.Div>
  <Interactive.Div name="Envíos nacionales" style={{...typography,position:'absolute',top:1474,left:100,right:160,fontSize:44,fontWeight:500,opacity:interpolate(frame,[25,37],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>(Envíos a todo el país 🇺🇾)</Interactive.Div>
 </AbsoluteFill>;
};
