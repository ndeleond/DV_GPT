import {Video} from '@remotion/media';
import {AbsoluteFill,Interactive,interpolate,staticFile,useCurrentFrame} from 'remotion';
import {Atmosphere,typography} from './design';
export const Hook=()=>{
 const frame=useCurrentFrame();
 return <AbsoluteFill style={{backgroundColor:'#362315'}}>
  <Video name="Macro — encendido" src={staticFile('hook.mp4')} muted durationInFrames={78} objectFit="cover" style={{width:'100%',height:'100%'}}/>
  <Atmosphere/>
  <Interactive.Div name="Gancho" style={{...typography,position:'absolute',top:292,left:100,right:160,fontSize:84,lineHeight:1.04,fontWeight:500,opacity:interpolate(frame,[0,5],[.85,1],{extrapolateRight:'clamp'}),translate:interpolate(frame,[0,12],['0px 12px','0px 0px'],{extrapolateRight:'clamp'})}}>¿El secreto para una<br/>casa que <span style={{fontWeight:700}}>SIEMPRE</span><br/>huele increíble ✨?</Interactive.Div>
 </AbsoluteFill>;
};
