import {Audio} from '@remotion/media';
import {TransitionSeries,linearTiming} from '@remotion/transitions';
import {fade} from '@remotion/transitions/fade';
import {AbsoluteFill,Composition,Folder,interpolate,staticFile,useCurrentFrame} from 'remotion';
import {Hook} from './Hook';
import {Quality} from './Quality';
import {Lifestyle} from './Lifestyle';
export const DeVelas=()=>{
 const frame=useCurrentFrame();
 return <AbsoluteFill>
  <TransitionSeries>
   <TransitionSeries.Sequence name="01 — Gancho" durationInFrames={78}><Hook/></TransitionSeries.Sequence>
   <TransitionSeries.Transition presentation={fade()} timing={linearTiming({durationInFrames:12})}/>
   <TransitionSeries.Sequence name="02 — Calidad" durationInFrames={132}><Quality/></TransitionSeries.Sequence>
   <TransitionSeries.Transition presentation={fade()} timing={linearTiming({durationInFrames:12})}/>
   <TransitionSeries.Sequence name="03 — Ambiente y compra" durationInFrames={174}><Lifestyle/></TransitionSeries.Sequence>
  </TransitionSeries>
  <Audio name="Sonido original de encendido" src={staticFile('ignition.wav')} durationInFrames={77} volume={1}/>
  <Audio name="Música ambiental original" src={staticFile('ambient.wav')} durationInFrames={360} volume={interpolate(frame,[0,24,60,84,330,359],[0,.35,.35,.8,.8,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}/>
 </AbsoluteFill>;
};
export const RemotionRoot=()=> <>
 <Composition id="DeVelas-Meta-15s" component={DeVelas} width={1080} height={1920} fps={24} durationInFrames={360}/>
 <Folder name="Escenas">
  <Composition id="Gancho" component={Hook} width={1080} height={1920} fps={24} durationInFrames={78}/>
  <Composition id="Calidad" component={Quality} width={1080} height={1920} fps={24} durationInFrames={132}/>
  <Composition id="Cierre" component={Lifestyle} width={1080} height={1920} fps={24} durationInFrames={174}/>
 </Folder>
</>;
