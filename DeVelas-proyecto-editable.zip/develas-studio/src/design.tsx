import {loadFont} from '@remotion/fonts';
import {AbsoluteFill, staticFile} from 'remotion';
loadFont({family:'Cormorant',url:staticFile('CormorantGaramond.ttf'),weight:'400 700'});
export const typography={fontFamily:'Cormorant, serif',color:'#FFF6E8',textShadow:'0 3px 18px rgba(20,10,3,.65)',textAlign:'center' as const};
export const Atmosphere=()=> <AbsoluteFill style={{background:'linear-gradient(180deg,rgba(30,15,5,.35),rgba(30,15,5,.12) 33%,transparent 48%,transparent 62%,rgba(22,12,7,.42))'}}/>;
