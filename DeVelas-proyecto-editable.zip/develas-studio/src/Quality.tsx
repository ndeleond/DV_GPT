import {Video} from '@remotion/media';
import {AbsoluteFill,Interactive,interpolate,staticFile,useCurrentFrame} from 'remotion';
import {Atmosphere,typography} from './design';
export const Quality=()=>{
 const frame=useCurrentFrame();
 return <AbsoluteFill style={{backgroundColor:'#362315'}}>
  <Video name="Cera — plano superior" src={staticFile('quality.mp4')} muted durationInFrames={132} objectFit="cover" style={{width:'100%',height:'100%'}}/>
  <Atmosphere/>
  <Interactive.Div name="Cera vegetal" style={{...typography,position:'absolute',top:310,left:100,right:160,fontSize:96,lineHeight:1.02,fontWeight:600,opacity:interpolate(frame,[5,17],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>100% Cera de<br/>Soja Vegetal</Interactive.Div>
  <Interactive.Div name="Origen artesanal" style={{...typography,position:'absolute',top:553,left:100,right:160,fontSize:52,lineHeight:1.12,opacity:interpolate(frame,[15,27],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>· Hecho a mano en Uruguay</Interactive.Div>
 </AbsoluteFill>;
};
