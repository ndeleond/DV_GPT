"""Original quiet music bed, generated without third-party recordings."""
import numpy as np
import wave
from pathlib import Path
sr=48000
t=np.arange(sr*15)/sr
stereo=np.zeros((len(t),2))
for start,notes in [(0,[130.8128,195.9977,293.6648]),(5,[110,164.8138,261.6256]),(10,[87.3071,130.8128,195.9977])]:
    local=np.maximum(t-start,0)
    env=np.where(t>=start,(1-np.exp(-local/1.1))*np.exp(-local/5),0)
    for index,hz in enumerate(notes):
        tone=(np.sin(2*np.pi*hz*t)+.15*np.sin(2*np.pi*hz*2*t))*env*.026
        stereo[:,0]+=tone*(1-.08*index)
        stereo[:,1]+=tone*(.84+.08*index)
for start,hz in [(1.6,523.2511),(3.6,587.3295),(6,659.2551),(8.2,523.2511),(10.4,391.9954),(12.5,523.2511)]:
    local=np.maximum(t-start,0)
    env=np.where(t>=start,(1-np.exp(-local/.04))*np.exp(-local/1.7),0)
    tone=(np.sin(2*np.pi*hz*local)+.12*np.sin(2*np.pi*2*hz*local))*env*.036
    stereo+=tone[:,None]
    for delay,gain in [(.21,.24),(.43,.12),(.67,.06)]:
        samples=int(delay*sr)
        stereo[samples:,0]+=tone[:-samples]*gain
        stereo[samples:,1]+=tone[:-samples]*gain*.9
stereo*=(np.minimum(t/1.3,1)*np.minimum((15-t)/1.5,1))[:,None]
with wave.open(str(Path(__file__).parent/'public/ambient.wav'),'wb') as out:
    out.setnchannels(2)
    out.setsampwidth(2)
    out.setframerate(sr)
    out.writeframes((np.clip(stereo,-1,1)*32767).astype('<i2').tobytes())
