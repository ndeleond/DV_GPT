# DeVelas — anuncio para Meta

Composición editable: `DeVelas-Meta-15s`, 1080 × 1920, 24 fps, 15 segundos.

- Gancho: 0–3 s. Macro del encendido, audio original filtrado y gancho serif marfil.
- Calidad: 3–8 s. Plano superior ralentizado, cera vegetal y origen artesanal.
- Cierre: 8–15 s. Living al atardecer ralentizado, marca, compra y envíos.
- Fundidos: 0,5 segundos, centrados en 3 y 8 segundos.
- Texto: Cormorant Garamond, fuente local con licencia OFL incluida. Márgenes: 100 px izquierda, 160 px derecha; textos entre 292 y 1530 px aproximadamente.
- Audio: encendido de 01.mp4 preservado sin cambiar su velocidad, filtrado y realzado; música ambiental original generada por `create-ambient.py`, con entrada suave y salida final. No se añade un chisporroteo artificial.

Los originales tienen 480 × 854 px. La composición reescala a Full HD; el detalle está limitado por esos originales. El clip 02 tiene vista superior oblicua y un pequeño charco de cera fundida, no un cenital perfecto ni toda la superficie líquida.

## Abrir y editar

```bash
cd /workspace/develas-studio
npm ci
npx remotion studio --no-open
```

Seleccionar `DeVelas-Meta-15s`. Los tres planos y sus textos tienen capas separadas. Las escenas también tienen composiciones independientes. Las fuentes y medios están en `public/`, sin dependencias remotas durante la reproducción.

## Exportar desde Studio

Usar Render, elegir H.264 (.mp4), 1080 × 1920, 24 fps y audio AAC. Alternativa CLI:

```bash
npx remotion render src/index.ts DeVelas-Meta-15s out/develas-meta-15s.mp4 --codec=h264 --crf=18 --audio-codec=aac
```

MP4 final exportado a `/workspace/DV_GPT/develas-meta-15s.mp4`, con el CTA corregido a `develasmontevideo.com`. Se han revisado imágenes de los tres bloques, los tipos de TypeScript y ESLint. La previsualización usa los clips H.264 normalizados para garantizar compatibilidad del navegador.

El CTA es un elemento gráfico; el destino del anuncio se configura en Meta Ads como `https://develasmontevideo.com`. Comprobar la ubicación concreta en Meta Ads antes de publicar, porque sus interfaces varían.
